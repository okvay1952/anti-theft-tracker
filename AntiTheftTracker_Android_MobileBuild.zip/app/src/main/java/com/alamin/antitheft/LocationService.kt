package com.alamin.antitheft

import android.app.*
import android.content.Context
import android.content.Intent
import android.location.*
import android.os.*
import androidx.core.app.NotificationCompat
import java.net.HttpURLConnection
import java.net.URL
import kotlin.concurrent.thread

class LocationService:Service(){
    private val channel="anti_theft_location"
    override fun onCreate(){
        super.onCreate()
        val nm=getSystemService(NotificationManager::class.java)
        if(Build.VERSION.SDK_INT>=26) nm.createNotificationChannel(NotificationChannel(channel,"Anti-Theft Location",NotificationManager.IMPORTANCE_LOW))
        val n=NotificationCompat.Builder(this,channel)
            .setContentTitle("Anti-Theft Tracker চলছে")
            .setContentText("Location protection is active")
            .setSmallIcon(android.R.drawable.ic_menu_mylocation)
            .setOngoing(true).setPriority(NotificationCompat.PRIORITY_LOW).build()
        if(Build.VERSION.SDK_INT>=29) startForeground(10,n,ServiceInfo.FOREGROUND_SERVICE_TYPE_LOCATION) else startForeground(10,n)
        startLocation()
    }
    private fun startLocation(){
        val lm=getSystemService(Context.LOCATION_SERVICE) as LocationManager
        val listener=object:LocationListener{override fun onLocationChanged(l:Location){send(l)}}
        try{lm.requestLocationUpdates(LocationManager.GPS_PROVIDER,60000L,10f,listener,Looper.getMainLooper())}catch(_:SecurityException){}
    }
    private fun send(l:Location){
        val p=getSharedPreferences("device",0)
        val base=p.getString("url","")?:""
        if(base.isBlank())return
        val did=p.getString("deviceId",Build.MODEL)?:Build.MODEL
        val sec=p.getString("secret","")?:""
        val body = "{"deviceId":"${esc(did)}","secret":"${esc(sec)}","latitude":${l.latitude},"longitude":${l.longitude},"accuracy":${l.accuracy},"timestamp":${System.currentTimeMillis()},"battery":${battery()}}"
        thread{
            try{
                val c=URL("$base/api/location").openConnection() as HttpURLConnection
                c.requestMethod="POST";c.connectTimeout=10000;c.readTimeout=10000;c.doOutput=true
                c.setRequestProperty("Content-Type","application/json")
                c.outputStream.use{it.write(body.toByteArray())}
                c.inputStream.close();c.disconnect()
            }catch(_:Exception){}
        }
    }
    private fun battery():Int=(getSystemService(BATTERY_SERVICE) as BatteryManager).getIntProperty(BatteryManager.BATTERY_PROPERTY_CAPACITY)
    private fun esc(s:String)=s.replace("\","\\").replace(""","\"")
    override fun onBind(i:Intent?)=null
}
