package com.alamin.antitheft

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.widget.*
import androidx.activity.ComponentActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat

class MainActivity : ComponentActivity() {
    private val req=100
    private lateinit var url:EditText
    private lateinit var id:EditText
    private lateinit var secret:EditText
    private lateinit var status:TextView

    override fun onCreate(b:Bundle?) {
        super.onCreate(b)
        val p=getSharedPreferences("device",0)
        val box=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(32,32,32,32)}
        box.addView(TextView(this).apply{text="Anti-Theft Tracker";textSize=26f})
        box.addView(TextView(this).apply{text="নিজের ফোনের Location পাঠানোর জন্য ব্যবহার করুন। Tracking চালু থাকলে Android notification দেখাবে."})
        url=EditText(this).apply{hint="Render server URL";setText(p.getString("url",""))}
        id=EditText(this).apply{hint="Device ID";setText(p.getString("deviceId",Build.MODEL))}
        secret=EditText(this).apply{hint="Device secret";setText(p.getString("secret",""))}
        val save=Button(this).apply{text="Save & Start Tracking"}
        val stop=Button(this).apply{text="Stop Tracking"}
        status=TextView(this).apply{text="Status: Ready";textSize=16f}
        box.addView(url);box.addView(id);box.addView(secret);box.addView(save);box.addView(stop);box.addView(status)
        setContentView(box)
        save.setOnClickListener{saveValues();requestAndStart()}
        stop.setOnClickListener{stopService(Intent(this,LocationService::class.java));status.text="Status: Tracking stopped"}
    }

    private fun saveValues(){
        getSharedPreferences("device",0).edit()
            .putString("url",url.text.toString().trim().removeSuffix("/"))
            .putString("deviceId",id.text.toString().trim())
            .putString("secret",secret.text.toString()).apply()
    }

    private fun requestAndStart(){
        val ps=mutableListOf(Manifest.permission.ACCESS_FINE_LOCATION,Manifest.permission.ACCESS_COARSE_LOCATION)
        if(Build.VERSION.SDK_INT>=33) ps.add(Manifest.permission.POST_NOTIFICATIONS)
        val miss=ps.filter{ContextCompat.checkSelfPermission(this,it)!=PackageManager.PERMISSION_GRANTED}
        if(miss.isNotEmpty()){ActivityCompat.requestPermissions(this,miss.toTypedArray(),req);return}
        if(Build.VERSION.SDK_INT>=29 && ContextCompat.checkSelfPermission(this,Manifest.permission.ACCESS_BACKGROUND_LOCATION)!=PackageManager.PERMISSION_GRANTED){
            status.text="App info → Permissions → Location → Allow all the time নির্বাচন করুন, তারপর আবার Start চাপুন।"
            startActivity(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS).apply{data=android.net.Uri.parse("package:$packageName")})
            return
        }
        ContextCompat.startForegroundService(this,Intent(this,LocationService::class.java))
        status.text="Status: Tracking started"
    }

    override fun onRequestPermissionsResult(c:Int,p:Array<out String>,r:IntArray){
        super.onRequestPermissionsResult(c,p,r)
        if(c==req && r.isNotEmpty() && r.all{it==PackageManager.PERMISSION_GRANTED}) requestAndStart()
        else if(c==req) status.text="Location permission প্রয়োজন।"
    }
}
