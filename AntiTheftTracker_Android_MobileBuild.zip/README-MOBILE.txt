মোবাইল দিয়ে APK বানানোর নিয়ম:
1) এই project-এর সব file/folder GitHub repository-তে upload করুন।
2) Branch main রাখুন।
3) GitHub > Actions > Build Android APK > Run workflow চাপুন।
4) সবুজ check এলে workflow খুলে Artifacts থেকে AntiTheftTracker-debug নিন।
5) ZIP খুলে app-debug.apk ইনস্টল করুন।

নোট: বর্তমান Render server শুধু /api/location গ্রহণ করে। পরের ধাপে আমরা server-এ নিরাপদ authentication, database এবং dashboard যোগ করব।
